import math
import numpy as np
import cmath
import matplotlib.pyplot as plt

u = 2
rho = 1
gamma = 1
L = 1
Nx = 5
phi_1 = 1
phi_N = 0

dx = L/Nx
dx2 = dx/2

x = np.zeros(5)
for i in range(Nx):
    x[i] = dx2 * (2*(i+1) - 1)

# Evaluate the Coefficients for LHS-BC, Central and RHS-BC points.
F = rho * u
D = gamma/dx
Pe = F/D

aW = np.zeros(Nx)
aE = np.zeros(Nx)
sP = np.zeros(Nx)
sU = np.zeros(Nx)
aW[0] = 0
aE[0] = D-F/2
sP[0] = -(2*D+F)
sU[0] = (2*D+F) * phi_1

for i in range(1,Nx-1):
    aW[i] = D + F/2
    aE[i] = D - F/2
    sP[i] = 0
    sU[i] = 0

aW[Nx-1] = D+F/2
aE[Nx-1] = 0
sP[Nx-1] = -(2*D-F)
sU[Nx-1] = (2*D-F)*phi_N

aP = aW + aE - sP

# Construct the matrix system
LHS = np.zeros(Nx*Nx).reshape(Nx,Nx)
LHS[0,1] = -aE[0]
LHS[0,0] = aP[0]

for i in range(1,Nx-1):
    LHS[i,i-1] = -aW[i]
    LHS[i,i] = aP[i]
    LHS[i,i+1] = -aE[i]

LHS[Nx-1,Nx-1] = aP[Nx-1]
LHS[Nx-1,Nx-2] = -aW[Nx-1]

RHS = np.arange(Nx).reshape(Nx,1)
RHS[0:Nx,0] = sU[0:Nx]

# Solve the system
phi = np.dot(np.linalg.inv(LHS),RHS)

# Compute the analytical solution
x2 = np.linspace(0,L,100)
num = np.exp(rho*u*x2/gamma)-1
den = np.exp(rho*u*L/gamma)-1
phi_exact = num/den*(phi_N-phi_1)+phi_1

image = plt.figure()
plt.plot(x2,phi_exact,'-k',label = "exact")
plt.plot(x,phi,'-ro',label = "FVM")
plt.grid()
plt.title("Peclet Number = {:.2f}".format(Pe))
plt.legend(loc = "best")
plt.xlabel('x[m]')
plt.ylabel("\phi")
plt.show()
